
public class PseudoDatabase
{

}
