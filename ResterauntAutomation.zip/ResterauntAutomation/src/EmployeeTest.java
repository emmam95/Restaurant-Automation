import student.TestCase;
public class EmployeeTest extends TestCase
{

}
