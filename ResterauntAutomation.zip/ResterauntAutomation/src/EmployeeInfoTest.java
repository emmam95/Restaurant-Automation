import student.TestCase;
public class EmployeeInfoTest extends TestCase
{

}
