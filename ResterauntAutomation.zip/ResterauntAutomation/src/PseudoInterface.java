
public class PseudoInterface
{

}
