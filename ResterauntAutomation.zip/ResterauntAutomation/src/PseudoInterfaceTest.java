import student.TestCase;
public class PseudoInterfaceTest extends TestCase
{

}
